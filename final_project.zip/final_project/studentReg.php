<?php 
    session_start();
    include("db.php");

    if ($_SERVER['REQUEST_METHOD'] == "POST") {        
            $StudentName = $_POST['sname'];
            $sid = $_POST['sid'];
            $sbatch = $_POST['sbatch'];
            $ptime = $_POST['ptime'];            
            $query = "INSERT INTO studentreg(sname, sid, sbatch, ptime) VALUES (?, ?, ?, ?)";
            $stmt = mysqli_prepare($con, $query);
            mysqli_stmt_bind_param($stmt, "ssss", $StudentName, $sid, $sbatch, $ptime);
            mysqli_stmt_execute($stmt);
            echo "<script type='text/javascript'> alert('Student Registration Complete')</script>";        
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="sreg">
        <h1>Student Registration</h1>
        <form method="POST">
            <label for="studentName">Student Name:</label>
            <input type="text" id="studentName" name="sname" required>
        
            <label for="studentID">Student ID:</label>
            <input type="text" id="studentID" name="sid" required>
        
            <label for="studentBatch">Student Batch:</label>
            <input type="text" id="studentBatch" name="sbatch" required>
            
            <label for="preferedTime">Prefered Time:</label>
            <input type="time" id="preferedTime" name="ptime" required>
        
            <button type="submit">Register Student</button>
            <!-- <button type="button" onclick="modifyStudent()">Modify Student</button> -->
        </form>
        <div class="btn">
            <button onclick="window.location.href = 'gameregi.php';">HOME</button>
        </div>
    </div>
    <div class="para">
        <p> "Always make a total effort, even when the odds are against you."<br>Best of Luck</p>
    </div>
    <script>
        function modifyStudent() {
            // Implement modification logic (e.g., send data to the server)
            alert('Student information modified!');
        }
    </script>
</body>
</html>
