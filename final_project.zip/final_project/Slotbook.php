<?php 
    session_start();
    include("db.php");

    if ($_SERVER['REQUEST_METHOD'] == "POST") {        
            $StudentName = $_POST['studentName'];
            $SelectGame = $_POST['game'];
            $SlotTime = $_POST['slotTime'];
            $query = "INSERT INTO slotbooking (sname, slctGame, slottime) VALUES (?, ?, ?)";
            $stmt = mysqli_prepare($con, $query);
            mysqli_stmt_bind_param($stmt, "sss", $StudentName, $SelectGame, $SlotTime);
            mysqli_stmt_execute($stmt);
            echo "<script type='text/javascript'> alert('Slot booked successfully!')</script>";        
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SlotBooking</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="slotbook">
    <h1>Slot Booking</h1>
    <section id="slotBooking">

    <form id="slotBookingForm" action="" method="POST">
        <label for="studentName">Student Name:</label>
        <input type="text" id="studentName" name="studentName" required>
    
        <label for="game">Select Game:</label>
        <select id="game" name="game" required>
            <option value="game1">Carrom Board</option>
            <option value="game2">Table Tennis</option>
            <option value="game3">Billiard</option>
            <option value="game4">Chess Board</option>
            <option value="game5">Foosball</option>
            <!-- Add more game options as needed -->
        </select>
    
        <label for="slotTime">Select Slot Time:</label>
        <input type="datetime-local" id="slotTime" name="slotTime" required>
    
        <button type="submit" >Book Slot</button>
        <!-- <button type="button" onclick="modifyGame()">Modify Game</button> -->
    
        <div id="errorMessage" class="error-message"></div>
    </form>
    <div class="btn">
        <button onclick="window.location.href = 'gameregi.php';">HOME</button>
        </div>
    </section>
    <script>
        function bookSlot() {
        // Implement slot booking logic and conflict checking here
        // For this example, let's assume there is a conflict
        $query ="insert into slotbooking(gname, gtype, bnumber, maxplayer) values ('$Gamename', '$Gametype','$BoardNumber', '$Maxplayer')";
        displayErrorMessage('Slot conflict! Please choose another time.');
    }

    function displayErrorMessage(message) {
        document.getElementById('errorMessage').innerText = message;
    }
    </script>
    </div>
    <div class="para">
        <P> "Nothing beats the feeling of being part of something bigger than yourself.Embrace it."<br>Best of Luck</P>
    </div>
    
</body>
</html>