
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            
        }

        header {
            text-align: center;
            margin-bottom: 20px;
        }

        nav {
            display: flex;
            justify-content: center;
            background-color:#5dd861;
            padding: 10px;
            font-size: 25px;
            
        }

        nav a {
            margin: 0 15px;
            text-decoration: none;
            color: #333;
            font-weight: bold;
        }

        main {
            max-width: 1000px;
        }
        .bg{
          position: relative;  
        }
        .bg img{
            width: 100%;
            height: auto;
        }
      .text-wrap {
            position: absolute;
            top: .5%;
            right: 67%;
            color: #fff;
            padding: 10px;
      }
      
      .text-wrap{
         perspective: 1000px;
         perspective-origin: 50% 50%;
}

.text{
    text-align: left;
    color: rgb(64, 231, 231);
    font-size: 4em;
    font-weight: bold;
    font-family: Helvetica;
    transition: 0.3s;
    transform: 
        rotateX(20deg)
        rotateY(1deg)
        rotateZ(-0deg)
        ;
    text-shadow: 
        -1px 1px 0 #eb0909,
        -2px 2px 0 #fd1b1b,
        -3px 3px 0 #fd1b1b,
        -4px 4px 0 #fd1b1b,
        -5px 5px 0 #fd1b1b,
        -6px 6px 1px rgba(0, 0, 0, 0.1),
        -1px 1px 3px rgba(0, 0, 0, .3),
        -3px 3px 5px rgba(0, 0, 0, .2), 
        -5px 5px 10px rgba(0, 0, 0, .25),
        -10px 10px 10px rgba(0, 0, 0, .2),
        -20px 20px 20px rgba(211, 24, 24, 0.15);
}

.text:hover{
    text-shadow: 
        -1px 1px 3px rgba(0, 0, 0, .3);
    transform: 
        translateY(0.1em)
        rotateX(20deg)
        rotateY(1deg)
        rotateZ(-0deg);
}
        
    </style>
</head>
<body>
    
<nav> 
    <div>
      <ul class="navbar-nav">
          <a class="nav-link" href="gameReg.php">Game Registration </a>
        
          <a class="nav-link" href="studentReg.php">Student Registration</a>
       
          <a class="nav-link" href="Slotbook.php">Slot Booking</a>
        </ul>
    </div>
</nav>
<div class="bg">
    <img src="game4.jpg">
    <div class="text-wrap">
        <p
        class="text"
        spellcheck="false">
        Wlecome To<br> Game Room
        </p>
    </div>
</div>

</body>
</html>