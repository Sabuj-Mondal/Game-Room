<?php
    $con = mysqli_connect("localhost", "root", "", "final_project") or die(mysql_error());
?>