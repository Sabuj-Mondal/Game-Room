<?php 
    session_start();
    include("db.php");

    if ($_SERVER['REQUEST_METHOD'] == "POST") {        
        $gname = $_POST['gname'];        
        $gtype = $_POST['gtype'];
        $bnumber = $_POST['bnumber'];
        $maxplayer = $_POST['maxplayer'];

        $query = "INSERT INTO gamereg (gname, gtype, bnumber, maxplayer) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($con, $query);
        mysqli_stmt_bind_param($stmt, "ssii", $gname, $gtype, $bnumber, $maxplayer);
        mysqli_stmt_execute($stmt);

        echo "<script type='text/javascript'> alert('Game Registration successfully!')</script>";        
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Game Registration</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="greg">
        <h1>Game Registration</h1>
        <form action="" method="POST">
            <label for="gameName">Game Name:</label>
            <input type="text" id="gameName" name="gname" required>
            
            <label for="gameType">Game Type:</label>
            <input type="text" id="gameType" name="gtype" required>

            <label for="boardNumber">Board Number:</label>
            <input type="text" id="boardNumber" name="bnumber" required>

            <label for="maxPlayers">Max Players:</label>
            <input type="text" id="maxPlayers" name="maxplayer" required>
    
            <button type="submit">Register Game</button>
        </form>
        <div class="btn">
            <button onclick="window.location.href = 'gameregi.php';">HOME</button>
        </div>
    </div>
    <div class="para">
        <p> "The best part about sports is the friendships you will make. Always be respectful."<br>Best of Luck</p>
    </div>
</body>
</html>
